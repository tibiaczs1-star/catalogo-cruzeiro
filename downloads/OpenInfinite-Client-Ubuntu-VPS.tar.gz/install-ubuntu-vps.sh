#!/usr/bin/env bash
set -euo pipefail

# Infinite Zone v6.2 — 1-Prompt Ubuntu 22.04 / 24.04 VPS Installer (No root required)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -f "$SCRIPT_DIR/bin/InfiniteClaude" ]; then
  APP_BIN="InfiniteClaude"
  APP_SLUG="infiniteclaude"
else
  APP_BIN="OpenInfinite"
  APP_SLUG="openinfinite"
fi

INSTALL_DIR="${INFINITEZONE_INSTALL_DIR:-$HOME/.local/share/$APP_SLUG}"
BIN_DIR="${INFINITEZONE_BIN_DIR:-$HOME/.local/bin}"
SYSTEMD_USER_DIR="$HOME/.config/systemd/user"

mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$HOME/.opencode-infinite/bin" "$SYSTEMD_USER_DIR"
cp -Rf "$SCRIPT_DIR/bin/"* "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/$APP_BIN"

cat > "$BIN_DIR/$APP_SLUG" <<EOF
#!/usr/bin/env bash
export DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1
exec "\$HOME/.local/share/$APP_SLUG/$APP_BIN" "\$@"
EOF
chmod +x "$BIN_DIR/$APP_SLUG"

cat > "$SYSTEMD_USER_DIR/$APP_SLUG.service" <<EOF
[Unit]
Description=$APP_BIN v6.2 Infinite Zone Local Gateway (:4114)
After=network-online.target

[Service]
Type=simple
WorkingDirectory=%h/.local/share/$APP_SLUG
ExecStart=%h/.local/share/$APP_SLUG/$APP_BIN --daemon
Restart=on-failure
RestartSec=5
Environment=DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1

[Install]
WantedBy=default.target
EOF

echo "[$APP_BIN] Executando autoteste de segurança Ed25519 + PBKDF2..."
"$INSTALL_DIR/$APP_BIN" --security-selftest

echo ""
echo "=================================================================="
echo " $APP_BIN v6.2 (Infinite Zone) instalado com sucesso!"
echo "=================================================================="
echo "  • TUI Nativa : $BIN_DIR/$APP_SLUG"
echo "  • Modo Daemon: $BIN_DIR/$APP_SLUG --daemon"
echo "  • Ativar     : $BIN_DIR/$APP_SLUG --activate SUA-CHAVE"
echo "  • Conectar   : $BIN_DIR/$APP_SLUG --inject-all"
echo "  • Aviso VPS  : Modo Linux VPS exige pedido pago e chave ativa."
echo "  • Checkout   : https://catalogo-cruzeiro-web.onrender.com/openinfinite/checkout/"
echo "=================================================================="
