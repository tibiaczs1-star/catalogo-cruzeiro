#!/usr/bin/env bash
set -euo pipefail

# OpenInfinite v6.1 — Instalador Ubuntu 22.04 / 24.04 LTS (Desktop & Headless VPS)
# Não requer root (instala em ~/.local/share/openinfinite e ~/.local/bin).
# NÃO habilita nem inicia serviços systemd ou daemons do Hermes automaticamente.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="${OPENINFINITE_INSTALL_DIR:-$HOME/.local/share/openinfinite}"
BIN_DIR="${OPENINFINITE_BIN_DIR:-$HOME/.local/bin}"
SYSTEMD_USER_DIR="$HOME/.config/systemd/user"

ARCH="$(uname -m)"
if [ "$ARCH" != "x86_64" ] && [ "$ARCH" != "amd64" ]; then
  echo "[OpenInfinite] Aviso: pacote compilado para linux-x64 (arquitetura atual: $ARCH)."
fi

if [ -f /etc/os-release ]; then
  . /etc/os-release
  echo "[OpenInfinite] Sistema detectado: ${PRETTY_NAME:-Linux}"
fi

mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$HOME/.opencode-infinite/bin" "$SYSTEMD_USER_DIR"

echo "[OpenInfinite] Copiando binários self-contained (.NET 9 linux-x64) para $INSTALL_DIR ..."
cp -Rf "$SCRIPT_DIR/bin/"* "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/OpenInfinite"

cat > "$BIN_DIR/openinfinite" <<'EOF'
#!/usr/bin/env bash
export DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1
exec "$HOME/.local/share/openinfinite/OpenInfinite" "$@"
EOF
chmod +x "$BIN_DIR/openinfinite"

# Copia unit opcional systemd --user (NÃO habilita automaticamente!)
if [ -f "$SCRIPT_DIR/openinfinite.service" ]; then
  cp -f "$SCRIPT_DIR/openinfinite.service" "$SYSTEMD_USER_DIR/openinfinite.service"
fi

echo "[OpenInfinite] Executando autoteste criptográfico Ed25519..."
"$INSTALL_DIR/OpenInfinite" --security-selftest

echo ""
echo "=================================================================="
echo " OpenInfinite v6.1 instalado com sucesso (sem exigir root)!"
echo "=================================================================="
echo " 1) Iniciar manualmente em primeiro plano:"
echo "      $BIN_DIR/openinfinite"
echo "    • Painel Web Local : http://127.0.0.1:4115/"
echo "    • Motor Infinite AI: http://127.0.0.1:4114/v1"
echo ""
echo " 2) Em uma VPS remota, acesse o painel com túnel SSH seguro:"
echo "      ssh -L 4115:127.0.0.1:4115 usuario@seu-servidor"
echo "    Ou ative sua chave Pro/Nível 3+ direto pelo terminal:"
echo "      $BIN_DIR/openinfinite --activate SUA-CHAVE-OI6-PRO"
echo ""
echo " 3) Opcional — systemd user unit instalada (DESATIVADA por padrão):"
echo "      systemctl --user daemon-reload"
echo "      systemctl --user enable --now openinfinite.service"
echo ""
echo " 4) Hermes Agent (Nous Research) — Planos Pro (R$ 159) / Nível 3+:"
echo "    Após ativar chave elegível, use manualmente:"
echo "      ~/.opencode-infinite/bin/infinite-hermes --tui"
echo "    (Nenhum daemon do Hermes é iniciado automaticamente.)"
echo "=================================================================="
