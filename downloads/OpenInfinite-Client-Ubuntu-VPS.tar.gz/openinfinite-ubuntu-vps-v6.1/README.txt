OpenInfinite v6.1 - Ubuntu 22.04 / 24.04 Desktop & VPS (linux-x64)
==================================================================
Instalacao sem root:
  tar -xzf OpenInfinite-Client-Ubuntu-VPS.tar.gz
  cd openinfinite-ubuntu-vps-v6.1
  ./install-ubuntu-vps.sh

Painel Web Local : http://127.0.0.1:4115/
Motor Infinite AI: http://127.0.0.1:4114/v1
